import mysql.connector as sql
from model import SVM
import pickle
from flask import Flask, request, render_template
app = Flask(__name__)

with open ('model.pkl','rb') as f:
	model = pickle.load(f)

@app.route("/")
def main():
    return render_template("login.html")

#%%
@app.route("/login", methods=['Post','Get'])
def login():
    global cursor
    mycon = sql.connect(host = "localhost", user = "root", passwd = "root", database = "cia")
    cursor = mycon.cursor()
    login_username = request.form.get("username")
    login_password = request.form.get("password")
    cursor.execute("select * from login")
    data = cursor.fetchall()
    username_list=[]
    password_list=[]

    for i in data:
        username_list.append(i[0])
        password_list.append(i[1])
    print(username_list)
    print(login_username)
    if login_username not in username_list:
        return render_template("login.html",info='Invalid Username. Username does not exist.Please try again')
    else:
        if login_password not in password_list:
            return render_template("login.html",info='Incorrect Password. Please try again')
        else:
            return render_template("predict.html")

#%%
@app.route("/predict",methods=['Post'])
def prediction():
    battery_power=request.form.get("battery_power")
    blue=request.form["blue"]
    clock_speed=request.form.get("clock_speed")
    dual_sim=request.form["dual_sim"]
    fc=request.form.get("fc")
    four_g=request.form["four_g"]
    int_memory=request.form.get("int_memory")
    mobile_wt=request.form.get("mobile_wt")
    n_cores=request.form["n_cores"]
    pc=request.form.get("pc")
    px_height=request.form.get("px_height")
    px_width=request.form.get("px_width")
    ram=request.form.get("ram")
    sc_h=request.form.get("sc_h")
    sc_w=request.form.get("sc_w")
    talk_time=request.form.get("talk_time")
    three_g=request.form["three_g"]
    touch_screen=request.form["touch_screen"]
    wifi=request.form["wifi"]
    
    print(battery_power,blue,clock_speed,dual_sim,fc,four_g,int_memory,mobile_wt,n_cores,pc,px_height,px_width,ram,sc_h,sc_w,talk_time,three_g,touch_screen,wifi)
    
    if blue=='yes':
        blue1=1
    else:
        blue1=0

    if dual_sim=='yes':
        dual_sim1=1
    else: 
        dual_sim1=0
        
    if four_g=='yes':
        four_g1=1
    else:
        four_g1=2

    if three_g=='yes':
        three_g1=1
    else: 
        three_g1=0

    if touch_screen=='yes':
        touch_screen1=1
    else: 
        touch_screen1=0

    if wifi=='yes':
        wifi1=1
    else: 
        wifi1=0
      
    predicted_charge=SVM.predict( [[int(battery_power),blue1,float(clock_speed),dual_sim1,int(fc),four_g1,int(int_memory),int(mobile_wt),int(n_cores),int(pc),int(px_height),int(px_width),int(ram),int(sc_h),int(sc_w),int(talk_time),three_g1,touch_screen1,wifi1]] )
    
    if predicted_charge[0]==0:
        res = "BELOW 10000"
    elif predicted_charge[0]==1:
        res = "10000 TO 15000"
    elif predicted_charge[0]==2:
        res = "15000 TO 20000"
    elif predicted_charge[0]==3:
        res = "ABOVE 20000"

    return render_template("success.html",input1=battery_power,input2=blue,input3=clock_speed,input4=dual_sim,input5=fc,input6=four_g,input7=int_memory,input8=mobile_wt,input9=n_cores,input10=pc,input11=px_height,input12=px_width,input13=ram,input14=sc_h,input15=sc_w,input16=talk_time,input17=three_g,input18=touch_screen,input19=wifi,result=res)

#%%
@app.route("/logout")
def logout():
    return render_template("login.html")

#%%
if __name__=='__main__':
    app.run(host='localhost',port=5000)