import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

data = pd.read_csv(r"trainmobile.csv")


data.drop('m_dep',axis=1,inplace=True)

data.drop(index=[1481,1933],inplace=True)
data.reset_index(inplace=True)
data.drop('index',axis=1,inplace=True)

df = pd.DataFrame(data)

x = df.drop('price_range',axis=1)
y = df['price_range']

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.25,random_state=42)

from sklearn.svm import SVC 
SVM = SVC()

SVM.fit(x_train,y_train)

y_pred = SVM.predict(x_test)
y_pred_train = SVM.predict(x_train)


#%%

import pickle

pickle.dump(SVM,open('model.pkl','wb'))
